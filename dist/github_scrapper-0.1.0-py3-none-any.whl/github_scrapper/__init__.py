from .app.git_code_scraper import GitCodeScraper as GitHubCodeScraper
